"""Flash the RS485 board's STC12C5A60S2 via its onboard CH340K."""

import argparse
from pathlib import Path
import time

import serial
from serial.tools import list_ports
from stcgal.ihex import IHex
from stcgal.protocols import Stc12Protocol, StcFramingException, StcProtocolException

TARGET_MAGIC = 0xD17E
CODE_SIZE = 60 * 1024


def load_firmware(path):
    if path.suffix.lower() in (".hex", ".ihx"):
        with path.open("rb") as image:
            hex_image = IHex.read(image)
        if not any(address == 0 and block for address, block in hex_image.areas.items()):
            raise ValueError("The HEX file has no code at the reset address (0x0000).")
        if any(address + len(block) > CODE_SIZE for address, block in hex_image.areas.items()):
            raise ValueError("The HEX file extends beyond the 60 KiB code area.")
        code = hex_image.extract_data()
    elif path.suffix.lower() == ".bin":
        code = path.read_bytes()
    else:
        raise ValueError("Use a .hex, .ihx, or .bin firmware file.")
    if not 0 < len(code) <= CODE_SIZE:
        raise ValueError("The code must occupy 1 to 61440 bytes.")
    return code + b"\xff" * (-len(code) % 512)


def find_ch340k(requested):
    ports = [
        port.device for port in list_ports.comports()
        if (port.vid, port.pid) == (0x1A86, 0x7522)
    ]
    if requested:
        if requested.upper() not in ports:
            raise ValueError(f"No CH340K on {requested}. Detected: {', '.join(ports) or 'none'}.")
        return requested.upper()
    if len(ports) != 1:
        raise ValueError(f"Expected one CH340K. Detected: {', '.join(ports) or 'none'}. Use --port if multiple are connected.")
    return ports[0]


def wait_for_target(probe):
    uart = probe.ser
    uart.reset_input_buffer()
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        try:
            probe.pulse(timeout=0.16)
        except serial.SerialTimeoutException:
            continue
        # Drain pending application replies before sending another sync byte.
        while uart.in_waiting and time.monotonic() < deadline:
            try:
                reply = probe.get_status_packet()
            except (serial.SerialTimeoutException, StcFramingException):
                continue
            if len(reply) >= 23:
                return reply
    raise TimeoutError("No STC ISP reply. Flash erase was not started.")


def flash(port, code):
    probe = Stc12Protocol(port, 2400, 9600)
    uart = serial.Serial(baudrate=2400, parity=serial.PARITY_EVEN,
                         timeout=0.3, write_timeout=1)
    uart.port = port
    uart.rts = False
    uart.dtr = False
    with uart:
        probe.ser = uart
        print(f"Waiting on {port}. Leave USB connected. Switch MCU power OFF, wait 4 seconds, then ON.", flush=True)
        reply = wait_for_target(probe)
        probe.status_packet = reply
        probe.initialize_model()
        if probe.mcu_magic != TARGET_MAGIC:
            raise ValueError(f"Unexpected MCU: {probe.model.name} ({probe.mcu_magic:04X}).")
        probe.initialize_status(reply)
        probe.initialize_options(reply)
        if probe.options.get_ee_erase():
            raise ValueError("EEPROM auto-erase is enabled on this MCU. Flash erase was not started.")
        uart.timeout = 3
        print(f"Target: {probe.model.name}, bootloader {probe.mcu_bsl_version}", flush=True)
        probe.handshake()
        probe.erase_flash(len(code), probe.model.code)
        probe.program_flash(code)
        probe.program_options()
        probe.disconnect()
        print("Flash complete.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("firmware", type=Path, help=".hex, .ihx, or .bin firmware")
    parser.add_argument("--port", help="CH340K port such as COM6. Auto-detected if omitted.")
    args = parser.parse_args()
    try:
        code = load_firmware(args.firmware)
        port = find_ch340k(args.port)
        flash(port, code)
    except (OSError, ValueError, StcProtocolException, StcFramingException) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
