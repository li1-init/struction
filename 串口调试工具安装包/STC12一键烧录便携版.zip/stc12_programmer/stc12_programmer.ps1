﻿Set-StrictMode -Version Latest

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$toolRoot = Join-Path $root 'stcgal'
$pythonPath = Join-Path $toolRoot 'python\python.exe'
$flashScript = Join-Path $toolRoot 'flash_stc12.py'

if (-not (Test-Path -LiteralPath $pythonPath) -or -not (Test-Path -LiteralPath $flashScript)) {
    [System.Windows.Forms.MessageBox]::Show(
        "找不到内置烧录工具，请确认 stcgal 文件夹完整。",
        "STC12 一键烧录",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'STC12 一键烧录'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = New-Object System.Drawing.Size(560, 410)
$form.MinimumSize = New-Object System.Drawing.Size(560, 410)
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'STC12C5A60S2 固件烧录'
$title.AutoSize = $true
$title.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 13, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(18, 14)
$form.Controls.Add($title)

$portLabel = New-Object System.Windows.Forms.Label
$portLabel.Text = '烧录串口'
$portLabel.AutoSize = $true
$portLabel.Location = New-Object System.Drawing.Point(20, 58)
$form.Controls.Add($portLabel)

$portCombo = New-Object System.Windows.Forms.ComboBox
$portCombo.Location = New-Object System.Drawing.Point(92, 54)
$portCombo.Size = New-Object System.Drawing.Size(145, 26)
$portCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$form.Controls.Add($portCombo)

$refreshButton = New-Object System.Windows.Forms.Button
$refreshButton.Text = '刷新'
$refreshButton.Location = New-Object System.Drawing.Point(245, 53)
$refreshButton.Size = New-Object System.Drawing.Size(60, 28)
$form.Controls.Add($refreshButton)

$fileLabel = New-Object System.Windows.Forms.Label
$fileLabel.Text = 'HEX 文件'
$fileLabel.AutoSize = $true
$fileLabel.Location = New-Object System.Drawing.Point(20, 99)
$form.Controls.Add($fileLabel)

$fileBox = New-Object System.Windows.Forms.TextBox
$fileBox.Location = New-Object System.Drawing.Point(92, 95)
$fileBox.Size = New-Object System.Drawing.Size(370, 26)
$fileBox.AllowDrop = $true
$form.Controls.Add($fileBox)

$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Text = '选择…'
$browseButton.Location = New-Object System.Drawing.Point(470, 94)
$browseButton.Size = New-Object System.Drawing.Size(72, 28)
$form.Controls.Add($browseButton)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = '操作提示：点击烧录后，保持 USB 连接，将 MCU 电源关闭约 4 秒，再重新打开。'
$hint.AutoSize = $false
$hint.Size = New-Object System.Drawing.Size(522, 38)
$hint.Location = New-Object System.Drawing.Point(20, 130)
$hint.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($hint)

$flashButton = New-Object System.Windows.Forms.Button
$flashButton.Text = '开始烧录'
$flashButton.Location = New-Object System.Drawing.Point(20, 174)
$flashButton.Size = New-Object System.Drawing.Size(110, 34)
$flashButton.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 215)
$flashButton.ForeColor = [System.Drawing.Color]::White
$flashButton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$form.Controls.Add($flashButton)

$status = New-Object System.Windows.Forms.Label
$status.Text = '请选择 CH340K 对应的串口。'
$status.AutoSize = $false
$status.Size = New-Object System.Drawing.Size(390, 30)
$status.Location = New-Object System.Drawing.Point(145, 178)
$status.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($status)

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = '烧录日志'
$logLabel.AutoSize = $true
$logLabel.Location = New-Object System.Drawing.Point(20, 222)
$form.Controls.Add($logLabel)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Location = New-Object System.Drawing.Point(20, 244)
$logBox.Size = New-Object System.Drawing.Size(522, 145)
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$logBox.BackColor = [System.Drawing.Color]::White
$logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$form.Controls.Add($logBox)

# Keep redirected process callbacks on the CLR side. PowerShell callbacks have
# no runspace on the process reader threads.
Add-Type -TypeDefinition @"
using System.Collections.Concurrent;
using System.Diagnostics;

public sealed class Stc12ProcessOutput
{
    public readonly ConcurrentQueue<string> Lines = new ConcurrentQueue<string>();

    public void Attach(Process process)
    {
        process.OutputDataReceived += Receive;
        process.ErrorDataReceived += Receive;
    }

    private void Receive(object sender, DataReceivedEventArgs args)
    {
        if (args.Data != null)
            Lines.Enqueue(args.Data);
    }
}
"@

$script:process = $null
$script:output = $null
$script:busy = $false

$exitButton = New-Object System.Windows.Forms.Button
$exitButton.Text = '退出'
$exitButton.Location = New-Object System.Drawing.Point(470, 174)
$exitButton.Size = New-Object System.Drawing.Size(72, 34)
$exitButton.Add_Click({ $form.Close() })
$form.Controls.Add($exitButton)
$status.Width = 315
function Add-LogLine {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) {
        return
    }
    $logBox.AppendText($Text + [Environment]::NewLine)
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
}

function Get-AvailablePorts {
    [System.IO.Ports.SerialPort]::GetPortNames() |
        Where-Object { $_ -match '^COM\d+$' } |
        Sort-Object { [int]($_.Substring(3)) } -Unique
}

function Update-PortList {
    try {
        $ports = @(Get-AvailablePorts)
    } catch {
        return
    }

    $before = @($portCombo.Items)
    if (($before -join ',') -eq ($ports -join ',')) {
        return
    }

    $previous = [string]$portCombo.SelectedItem
    $portCombo.BeginUpdate()
    try {
        $portCombo.Items.Clear()
        foreach ($port in $ports) {
            [void]$portCombo.Items.Add($port)
        }
        if ($previous) {
            $portCombo.SelectedIndex = $portCombo.Items.IndexOf($previous)
        }
    } finally {
        $portCombo.EndUpdate()
    }

    $flashButton.Enabled = (-not $script:busy) -and ($portCombo.SelectedIndex -ge 0)
}
function Set-ControlsBusy {
    param([bool]$Value)
    $script:busy = $Value
    $portCombo.Enabled = -not $Value
    $refreshButton.Enabled = -not $Value
    $fileBox.Enabled = -not $Value
    $browseButton.Enabled = -not $Value
    $exitButton.Enabled = -not $Value
    $flashButton.Enabled = (-not $Value) -and ($portCombo.SelectedIndex -ge 0)
}

$flashButton.Enabled = $false
$portCombo.Add_SelectedIndexChanged({
    $flashButton.Enabled = (-not $script:busy) -and ($portCombo.SelectedIndex -ge 0)
})

$refreshButton.Add_Click({
    if (-not $busy) {
        Update-PortList
    }
})

$browseButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = '选择 Intel HEX 固件'
    $dialog.Filter = 'Intel HEX 文件 (*.hex)|*.hex'
    $dialog.CheckFileExists = $true
    $dialog.Multiselect = $false
    if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $fileBox.Text = $dialog.FileName
    }
    $dialog.Dispose()
})

$fileBox.Add_DragEnter({
    if ($_.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
        $_.Effect = [System.Windows.Forms.DragDropEffects]::Copy
    }
})

$fileBox.Add_DragDrop({
    $dropped = @($_.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop))
    if ($dropped.Count -gt 0 -and [IO.Path]::GetExtension($dropped[0]).ToLowerInvariant() -eq '.hex') {
        $fileBox.Text = $dropped[0]
    }
})

$flashButton.Add_Click({
    if ($busy) {
        return
    }

    $port = [string]$portCombo.SelectedItem
    $firmware = $fileBox.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($port)) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            '请先选择烧录串口。',
            '缺少串口',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    if ([string]::IsNullOrWhiteSpace($firmware) -or -not (Test-Path -LiteralPath $firmware -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            '请选择一个存在的 .hex 固件文件。',
            '缺少 HEX 文件',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    if ([IO.Path]::GetExtension($firmware).ToLowerInvariant() -ne '.hex') {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            '固件文件必须是 .hex 格式。',
            '文件格式错误',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    try {
        $firstLine = (Get-Content -LiteralPath $firmware -TotalCount 1 -ErrorAction Stop).Trim()
        if (-not $firstLine.StartsWith(':')) {
            throw '文件内容不是 Intel HEX 格式。'
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            $_.Exception.Message,
            'HEX 文件无效',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    $script:output = [Stc12ProcessOutput]::new()
    $logBox.Clear()
    Add-LogLine "串口：$port"
    Add-LogLine "固件：$firmware"
    Add-LogLine '正在启动烧录工具…'
    Add-LogLine '请保持 USB 连接，MCU 断电约 4 秒后重新上电。'
    Set-ControlsBusy $true
    $status.Text = '等待单片机进入 ISP 烧录模式…'

    $started = $false
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $pythonPath
        $psi.Arguments = '-X utf8 "' + $flashScript + '" "' + $firmware + '" --port "' + $port + '"'
        $psi.WorkingDirectory = $toolRoot
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
        $psi.StandardErrorEncoding = [Text.Encoding]::UTF8

        $script:process = New-Object System.Diagnostics.Process
        $script:process.StartInfo = $psi
        $script:output.Attach($script:process)

        if (-not $script:process.Start()) {
            throw '无法启动烧录工具。'
        }
        $started = $true
        $script:process.BeginOutputReadLine()
        $script:process.BeginErrorReadLine()
    } catch {
        Add-LogLine "启动失败：$($_.Exception.Message)"
        Set-ControlsBusy $false
        $status.Text = '启动失败。'
        if ($null -ne $script:process) {
            try {
                if ($started -and -not $script:process.HasExited) {
                    $script:process.Kill()
                }
            } catch {
                Add-LogLine "无法结束烧录工具：$($_.Exception.Message)"
            } finally {
                $script:process.Dispose()
                $script:process = $null
            }
        }
        $script:output = $null
    }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 100
$timer.Add_Tick({
    if ($null -eq $script:process) {
        return
    }

    $finished = $script:process.HasExited
    if ($finished) {
        # The parameterless overload waits for redirected output callbacks.
        $script:process.WaitForExit()
    }

    $line = $null
    while ($script:output.Lines.TryDequeue([ref]$line)) {
        Add-LogLine $line
    }

    if ($finished) {
        $exitCode = $script:process.ExitCode
        $script:process.Dispose()
        $script:process = $null
        $script:output = $null
        if ($exitCode -eq 0) {
            Add-LogLine '烧录完成。'
            $status.Text = '烧录成功。点击“退出”关闭窗口。'
        } else {
            Add-LogLine "烧录失败，退出码 $exitCode。"
            $status.Text = '烧录失败，请查看日志。'
        }
        Update-PortList
        Set-ControlsBusy $false
    }
})

$portTimer = New-Object System.Windows.Forms.Timer
$portTimer.Interval = 750
$portTimer.Add_Tick({
    Update-PortList
})

$form.Add_Shown({
    Update-PortList
    $timer.Start()
    $portTimer.Start()
})
$form.Add_FormClosing({
    if ($busy) {
        $_.Cancel = $true
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            '烧录正在进行，请等待完成后再关闭窗口。',
            '请稍候',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
})

[void]$form.ShowDialog()
$portTimer.Stop()
$portTimer.Dispose()
$timer.Stop()
$timer.Dispose()
$form.Dispose()
